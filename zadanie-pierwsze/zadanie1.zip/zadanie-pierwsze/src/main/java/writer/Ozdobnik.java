package writer;

public interface Ozdobnik {
    String ozdabiaj(String s);
}
