package writer;

public class OzdobnikZnakiWiekszosci implements IOzdobnik {
    @Override
    public String ozdob(String s) {
        return ">>>>>" + s + ">>>>>";
    }
}

