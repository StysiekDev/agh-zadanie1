package writer;

public interface IOzdobnik {
    String ozdob(String s);


}