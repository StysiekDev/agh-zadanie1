package writer;

public interface IWriter {
	public void writer(String s);
}