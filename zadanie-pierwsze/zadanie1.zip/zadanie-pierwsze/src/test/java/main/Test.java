package main;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test {


	@org.junit.jupiter.api.Test
	void contextLoads() {
	}

}
